package hw1;

public class CoffeeMaker extends BeverageMaker{
	 public void brew() {
		    System.out.println("把熱水倒進磨好的咖啡粉");
	}
	 
	 public void addCondiments() {
		    System.out.println("添加糖或牛奶等額外添加物");
	}
	 
	 public void addIce() {}

}
