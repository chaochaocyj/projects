package hw2;

public interface Compare {
	abstract public boolean compare(Object d1,Object d2);
}
