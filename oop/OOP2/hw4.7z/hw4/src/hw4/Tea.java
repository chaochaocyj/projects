package hw4;

public interface Tea {
	  /* 取得成分說明 */
	  public String getIngredient();
	  /* 取得成分價錢 */
	  public int getCost();
}
