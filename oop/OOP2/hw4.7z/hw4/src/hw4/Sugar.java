package hw4;

public class Sugar implements Tea {
	Tea t;
	int cost = 5;
	Sugar(){} // 建構子
	Sugar(Tea already){
		t = already;
	}
	@Override
	public String getIngredient() {
		if(t != null)
			return "糖\n" + t.getIngredient();
		else
			return "糖\n";
	}

	@Override
	public int getCost() {
		if(t != null)
			return cost + t.getCost();
		else
			return cost;
	}

}
