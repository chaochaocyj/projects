package hw4;

public class GreenTea implements Tea {
	Tea t;
	int cost = 20;
	GreenTea(){} // 建構子
	GreenTea(Tea already){
		t = already;
	}
	@Override
	public String getIngredient() {
		if(t != null)
			return "綠茶\n" + t.getIngredient();
		else
			return "綠茶\n";
	}

	@Override
	public int getCost() {
		if(t != null)
			return cost + t.getCost();
		else
			return cost;
	}

}
