package hw3;

public interface Control {
	public void execute();
}
